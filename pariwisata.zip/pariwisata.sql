-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2017 at 04:33 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pariwisata`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id_admin` int(4) NOT NULL,
  `username` varchar(30) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `nama_lengkap`, `email`, `password`, `no_hp`, `alamat`) VALUES
(1, 'yahya', 'Muhammad Yahya', 'moch.yahya95@gmail.com', '59202463fd4c312b063293b88f6063b2', '089656729025', '<p>Desa Setupatok Blok Sibacin</p>');

-- --------------------------------------------------------

--
-- Table structure for table `album_galeri`
--

CREATE TABLE IF NOT EXISTS `album_galeri` (
`id_album` int(11) NOT NULL,
  `nama_album` varchar(30) NOT NULL,
  `tanggal_album` date NOT NULL,
  `deskripsi_album` varchar(160) NOT NULL,
  `foto_album` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `album_galeri`
--

INSERT INTO `album_galeri` (`id_album`, `nama_album`, `tanggal_album`, `deskripsi_album`, `foto_album`) VALUES
(10, 'Keraton Kasepuhan', '2017-06-29', 'Kenangan Keraton Kasepuhan', 'De_kraton_Kasepuhan_Cheribon.jpg'),
(11, 'Keraton Kacirebonan', '2017-06-29', 'Album Galeri Keraton Kacirebonan', '220px-Keraton-kacirebonan.jpg'),
(12, 'Keraton Kanoman', '2017-06-29', 'Album Galeri Keraton Kanoman', '300px-COLLECTIE_TROPENMUSEUM.jpg'),
(13, 'Situs Sunyaragi', '2017-07-01', '<p>Kenangan Pada Saat berkunjung di Situs Sunyaragiiiii</p>', 'DSC_0300.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE IF NOT EXISTS `artikel` (
`kd_artikel` int(11) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `tgl_artikel` date NOT NULL,
  `ringkasan` varchar(360) NOT NULL,
  `isi` text NOT NULL,
  `gambar` varchar(30) NOT NULL,
  `kd_kategori` int(11) NOT NULL,
  `penulis` varchar(30) NOT NULL,
  `terbit` enum('0','1') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`kd_artikel`, `judul`, `tgl_artikel`, `ringkasan`, `isi`, `gambar`, `kd_kategori`, `penulis`, `terbit`) VALUES
(1, 'Goa Sunyaragi, Kota Cirebon', '2017-07-06', '<p>Goa Sunyaragi merupakan Gua yang terletak di jalan by pass kota cirebon, untuk masuk ke Goa Sunyaragi anda cukup membayar uang sebesar Rp. 10.000, dengan uang 10.000 anda dapat menikmati...</p>', '<p>Goa Sunyaragi merupakan Gua yang terletak di jalan by pass kota cirebon, untuk masuk ke Goa Sunyaragi anda cukup membayar uang sebesar Rp. 10.000, dengan uang 10.000 anda dapat menikmati...</p>', 'DSC_0329.JPG', 2, 'Muhammad Yahya', '1'),
(2, 'Keraton Kasepuhan, Kota Cirebon', '2017-05-17', 'Keraton Kasepuhan telah mengalami perubahan yang amat sangat pesat', 'Keraton Kasepuhan telah mengalami perubahan yang amat sangat pesat, oleh karena itu untuk menikmati dan mencari informasi tentang kasepuhan di kenakan biaya yang lumayan menguras isi dompet kalian', 'thumb01.jpg', 3, 'Administrator', '0'),
(3, 'Keraton Kacirebonan, Kota Cirebon', '2017-06-29', '<p style="margin: 0.5em 0px; line-height: inherit; color: #222222; font-family: sans-serif; font-size: 14px;"><strong>Kecirebonan</strong>&nbsp;dibangun pada ta', '<p style="margin: 0.5em 0px; line-height: inherit; color: #222222; font-family: sans-serif; font-size: 14px;"><strong>Kecirebonan</strong>&nbsp;dibangun pada tanggal 1800 M, Bangunan kolonial ini banyak menyimpan benda-benda peninggalan sejarah seperti&nbsp;<a style="text-decoration-line: none; color: #0b0080; background: none;" title="Keris" href="https://id.wikipedia.org/wiki/Keris">Keris</a>,&nbsp;<a style="text-decoration-line: none; color: #0b0080; background: none;" title="Wayang" href="https://id.wikipedia.org/wiki/Wayang">Wayang</a>, perlengkapan Perang,&nbsp;<a style="text-decoration-line: none; color: #0b0080; background: none;" title="Gamelan" href="https://id.wikipedia.org/wiki/Gamelan">Gamelan</a>&nbsp;dan lain-lain.</p>\r\n<p style="margin: 0.5em 0px; line-height: inherit; color: #222222; font-family: sans-serif; font-size: 14px;">Seperti halnya&nbsp;<a style="text-decoration-line: none; color: #0b0080; background: none;" title="Keraton Kasepuhan" href="https://id.wikipedia.org/wiki/Keraton_Kasepuhan">Keraton Kasepuhan</a>&nbsp;dan&nbsp;<a style="text-decoration-line: none; color: #0b0080; background: none;" title="Keraton Kanoman" href="https://id.wikipedia.org/wiki/Keraton_Kanoman">Keraton Kanoman</a>, Kecirebonan pun tetap menjaga, melestarikan serta melaksanakan kebiasaan dan upacara adat seperti&nbsp;<a class="new" style="text-decoration-line: none; color: #a55858; background: none;" title="Upacara Pajang Jimat (halaman belum tersedia)" href="https://id.wikipedia.org/w/index.php?title=Upacara_Pajang_Jimat&amp;action=edit&amp;redlink=1">Upacara Pajang Jimat</a>&nbsp;dan sebagainya.</p>\r\n<p style="margin: 0.5em 0px; line-height: inherit; color: #222222; font-family: sans-serif; font-size: 14px;"><strong>Kacirebonan</strong>&nbsp;berada di wilayah kelurahan Pulasaren Kecamatan&nbsp;<a style="text-decoration-line: none; color: #0b0080; background: none;" title="Pekalipan, Cirebon" href="https://id.wikipedia.org/wiki/Pekalipan,_Cirebon">Pekalipan</a>, tepatnya 1&nbsp;km sebelah barat daya dari&nbsp;<a style="text-decoration-line: none; color: #0b0080; background: none;" title="Keraton Kasepuhan" href="https://id.wikipedia.org/wiki/Keraton_Kasepuhan">Keraton Kasepuhan</a>&nbsp;dan kurang lebih 500 meter sebelah selatan&nbsp;<a style="text-decoration-line: none; color: #0b0080; background: none;" title="Keraton Kanoman" href="https://id.wikipedia.org/wiki/Keraton_Kanoman">Keraton Kanoman</a>. Keraton Kacirebonan posisinya memanjang dari utara ke selatan (posisi yang sama dengan keraton-keraton lain di Cirebon) dengan luas tanah sekitar 46.500 meter persegi.<sup id="cite_ref-1" class="reference" style="line-height: 1em; unicode-bidi: isolate; white-space: nowrap;"><a style="text-decoration-line: none; color: #0b0080; background: none;" href="https://id.wikipedia.org/wiki/Keraton_Kacirebonan#cite_note-1">[1]</a></sup></p>', '120px-Keraton_kacirebonan3.jpg', 3, 'Administrator', '0'),
(5, 'Penegasan Kaprabonan sebagai Peguron', '2017-06-29', '<p style="margin: 0.5em 0px; line-height: inherit; color: #222222; font-family: sans-serif; font-size: 14px; text-align: justify;">Pada tahun 2011 Pangeran Hempi membuat sebuah pernyataan bahwa Kaprabonan bukanlah sekadar sebuah&nbsp;<em>peguron</em>&nbsp;saja namun juga bersifat sebagai&nbsp;<em>kerajaan</em>, terlebih adanya pengakuan dari pejabat penguasa', '<p style="margin: 0.5em 0px; line-height: inherit; color: #222222; font-family: sans-serif; font-size: 14px; text-align: justify;">Pada tahun 2011 Pangeran Hempi membuat sebuah pernyataan bahwa Kaprabonan bukanlah sekadar sebuah&nbsp;<em>peguron</em>&nbsp;saja namun juga bersifat sebagai&nbsp;<em>kerajaan</em>, terlebih adanya pengakuan dari pejabat penguasa cirebon (zaman penjajahan Jepang) pada sekitar tahun 1946 pada masa kepemimpinan Pangeran Aruman bahwa Kaprabon adalah sebuah&nbsp;<em>kerajaan</em>.</p>\r\n<p style="margin: 0.5em 0px; line-height: inherit; color: #222222; font-family: sans-serif; font-size: 14px; text-align: justify;">Pertemuan pelurusan sejarah Kaprabonan pun digelar pada tahun yang sama oleh keluarga besar Kaprabonan dan kemudian sesepuh keluarga besar Kaprabonan yaitu Pangeran Moh Nurbuwat Purbaningrat menyatakan bahwa tidak ada satupun catatan sejarah yang menyebutkan Kaprabonan berdiri sebagai kesultanan<sup id="cite_ref-5" class="reference" style="line-height: 1em; unicode-bidi: isolate; white-space: nowrap;"><a style="text-decoration-line: none; color: #0b0080; background: none;" href="https://id.wikipedia.org/wiki/Kaprabonan#cite_note-5">[5]</a></sup>&nbsp;atau keraton, pernyataan Pangeran Moh Nurbuwat juga diperkuat oleh sesepuh Kaprabonan lainnya yaitu Pangeran Maulana Cakraningrat&nbsp;:</p>\r\n<table class="cquote" style="font-size: 14px; background: transparent; color: #222222; font-family: sans-serif; margin: auto; border-collapse: collapse; border: none; width: auto;" border="0">\r\n<tbody>\r\n<tr>\r\n<td style="width: 20px; vertical-align: top; border: none; color: #b2b7f2; font-size: 40px; font-family: &quot;Times New Roman&quot;, Times, serif; font-weight: bold; line-height: 0.6em; padding: 10px;">&ldquo;</td>\r\n<td style="vertical-align: top; border: none; padding: 4px 10px;">Dia (red: Pangeran Raja Adipati (PRA) Kaprabon) dulunya menolak berkuasa di Keraton Kanoman dan memilih mendirikan perguruan karena lebih tertarik memperdalam Tarekat Islam</td>\r\n<td style="width: 20px; vertical-align: bottom; border: none; color: #b2b7f2; font-size: 40px; font-family: &quot;Times New Roman&quot;, Times, serif; font-weight: bold; line-height: 0.6em; text-align: right; padding: 10px;">&rdquo;</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p style="margin: 0.5em 0px; line-height: inherit; color: #222222; font-family: sans-serif; font-size: 14px; text-align: justify;">kerabat Kaprabonan lainnya menjelaskan jika pada masa kepemimpinan Jepang di Indonesia telah terjadi kekeliruan pengakuan, surat dari penguasa Jepang pada saat itu yang mengakui Kaprabonan sebagai sebuah kesultanan atau kerajaan dikarenakan adanya kesalahan dari pihak Kaprabonan ketika mengirimkan surat kepada pemerintah penguasaan Jepang, dikarenakan pada surat yang dikirim oleh pihak Kaprabonan bertuliskan Kaprabonan sebagai keraton maka pihak penguasa Jepang pada saat itu dikarenakan ketidaktahuan sejarah Cirebon membalas surat dari Kaprabonan dengan kata-kata Keraton Kaprabonan, surat balasan inilah yang kemudian dijadikan dasar oleh pihak Kaprabonan untuk menyatakan dirinya sebagai keraton.</p>', 'keraton-kacirebonan.jpg', 3, 'Muhammad Yahya', '1');

-- --------------------------------------------------------

--
-- Table structure for table `detail_harga`
--

CREATE TABLE IF NOT EXISTS `detail_harga` (
  `kd_detailharga` int(3) NOT NULL,
  `kd_inap` int(3) NOT NULL,
  `jenis` enum('Deluxe Double','Deluxe Tripel','VIP Room','Standar Tripel Bed') NOT NULL,
  `harga` varchar(30) NOT NULL,
  `gambar` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `kd_event` int(11) NOT NULL,
  `nama_event` varchar(50) NOT NULL,
  `tgl_event` date NOT NULL,
  `tempat` varchar(50) NOT NULL,
  `isi` text NOT NULL,
  `gambar` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`kd_event`, `nama_event`, `tgl_event`, `tempat`, `isi`, `gambar`) VALUES
(1, 'Jalan Santai Bersama Sultan', '2017-06-22', 'Keraton Kasepuhan', 'Kini Keraton Kasepuhan kembali mengajak kalian untuk Mengikuti Jalan Santai,,, ', 'no_gambar.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `galeri`
--

CREATE TABLE IF NOT EXISTS `galeri` (
`id_galeri` int(11) NOT NULL,
  `nama_galeri` varchar(60) NOT NULL,
  `id_album` int(11) NOT NULL,
  `tanggal_galeri` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `galeri`
--

INSERT INTO `galeri` (`id_galeri`, `nama_galeri`, `id_album`, `tanggal_galeri`) VALUES
(19, '300px-Kasepuhan-377.jpg', 10, '2017-06-29'),
(20, '300px-Mosque_of_Keraton_Kasepuhan.jpg', 10, '2017-06-29'),
(21, '300px-Museum_Sonobudoyo.JPG', 10, '2017-06-29'),
(22, '300px-Reynan-Kasepuhan-Kutagara.jpg', 10, '2017-06-29'),
(23, '300px-Reynan-Kasepuhan-Lunjuk.jpg', 10, '2017-06-29'),
(24, '300px-Symbol_Keraton_Kasepuhan.jpg', 10, '2017-06-29'),
(25, '220px-Keraton-kacirebonan.jpg', 11, '2017-06-29'),
(26, '220px-Reynan-kacirebonan-Koriagung.jpg', 11, '2017-06-29'),
(27, '220px-Reynan-kacirebonan-Paseban.jpg', 11, '2017-06-29'),
(28, '220px-Keraton_kacirebonan3.jpg', 11, '2017-06-29'),
(29, '300px-COLLECTIE_TROPENMUSEUM.jpg', 12, '2017-06-29'),
(30, '300px-Keraton_Kanoman_Cirebon.jpg', 12, '2017-06-29'),
(32, 'DSC_0284.JPG', 13, '2017-06-30');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
`kd_kategori` int(11) NOT NULL,
  `judul` varchar(30) NOT NULL,
  `link` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`kd_kategori`, `judul`, `link`) VALUES
(2, 'Objek Wisata Alam', 'wisataalam'),
(3, 'Objek Wisata Bangunan', 'wisatabangun');

-- --------------------------------------------------------

--
-- Table structure for table `komentar_artikel`
--

CREATE TABLE IF NOT EXISTS `komentar_artikel` (
`kd_komartikel` int(7) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `isi_komentar` text NOT NULL,
  `tanggal` date NOT NULL,
  `status` enum('0','1') NOT NULL,
  `kd_artikel` int(7) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `komentar_artikel`
--

INSERT INTO `komentar_artikel` (`kd_komartikel`, `nama`, `email`, `isi_komentar`, `tanggal`, `status`, `kd_artikel`) VALUES
(1, 'yahya', 'ebes@gmail.com', 'Bagus gan', '2017-06-06', '1', 1),
(5, 'Yahyaaa', 'muhammad.yahya20@yahoo.com', 'Bagus Gan', '2017-06-29', '1', 1),
(6, 'Yahya', 'Bag@gmail', 'Lumayan Bagus Kang', '2017-06-29', '1', 2);

-- --------------------------------------------------------

--
-- Table structure for table `linklist`
--

CREATE TABLE IF NOT EXISTS `linklist` (
`id` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `link` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `linklist`
--

INSERT INTO `linklist` (`id`, `nama`, `link`) VALUES
(1, 'DISPORBUDBAR', 'http://disporbudpar.cirebonkota.go.id'),
(2, 'Cirebon Kota', 'http://cirebonkota.go.id');

-- --------------------------------------------------------

--
-- Table structure for table `markers`
--

CREATE TABLE IF NOT EXISTS `markers` (
`id` int(11) NOT NULL,
  `nama` varchar(60) NOT NULL,
  `alamat` varchar(80) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `tipe` varchar(30) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `markers`
--

INSERT INTO `markers` (`id`, `nama`, `alamat`, `lat`, `lng`, `tipe`) VALUES
(1, 'Keraton Kasepuhan', 'Pegajahan, Kota Cirebon', -6.726334, 108.571007, 'Wisata'),
(2, 'Keraton Kanoman', 'Jalan Kanoman, Lemahwungkuk Kota Cirebon', -6.722393, 108.565636, 'Wisata'),
(3, 'Goa Sunyaragi', 'Kel. Sunyaragi, Kota Cirebon', -6.737237, 108.540604, 'Wisata'),
(4, 'Pantai Kejawanan', 'Jl. Kejawanan, Kota Cirebon', -6.733613, 108.583603, 'Wisata');

-- --------------------------------------------------------

--
-- Table structure for table `menu_home`
--

CREATE TABLE IF NOT EXISTS `menu_home` (
  `kd_menu` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `link` text NOT NULL,
  `gambar` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_home`
--

INSERT INTO `menu_home` (`kd_menu`, `judul`, `link`, `gambar`) VALUES
(1, 'Beranda', 'index.php?page=home', '-'),
(2, 'Profile', 'index.php?page=profile', ''),
(3, 'Berita', 'index.php?page=artikel', ''),
(4, 'Lokasi', 'index.php?page=obwis', '#'),
(5, 'Galerry', 'index.php?page=galeri', '-'),
(7, 'About Us', 'index.php?page=contact', '-');

-- --------------------------------------------------------

--
-- Table structure for table `objek_wisata`
--

CREATE TABLE IF NOT EXISTS `objek_wisata` (
  `kd_wisata` int(3) NOT NULL,
  `nama_wisata` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` varchar(30) NOT NULL,
  `rute` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `penginapan`
--

CREATE TABLE IF NOT EXISTS `penginapan` (
  `kd_inap` int(3) NOT NULL,
  `nama_inap` varchar(30) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `kontak` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `website` varchar(50) NOT NULL,
  `gambar` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `album_galeri`
--
ALTER TABLE `album_galeri`
 ADD PRIMARY KEY (`id_album`);

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
 ADD PRIMARY KEY (`kd_artikel`);

--
-- Indexes for table `detail_harga`
--
ALTER TABLE `detail_harga`
 ADD PRIMARY KEY (`kd_detailharga`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
 ADD PRIMARY KEY (`kd_event`);

--
-- Indexes for table `galeri`
--
ALTER TABLE `galeri`
 ADD PRIMARY KEY (`id_galeri`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
 ADD PRIMARY KEY (`kd_kategori`);

--
-- Indexes for table `komentar_artikel`
--
ALTER TABLE `komentar_artikel`
 ADD PRIMARY KEY (`kd_komartikel`);

--
-- Indexes for table `linklist`
--
ALTER TABLE `linklist`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `markers`
--
ALTER TABLE `markers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_home`
--
ALTER TABLE `menu_home`
 ADD PRIMARY KEY (`kd_menu`);

--
-- Indexes for table `objek_wisata`
--
ALTER TABLE `objek_wisata`
 ADD PRIMARY KEY (`kd_wisata`);

--
-- Indexes for table `penginapan`
--
ALTER TABLE `penginapan`
 ADD PRIMARY KEY (`kd_inap`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id_admin` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `album_galeri`
--
ALTER TABLE `album_galeri`
MODIFY `id_album` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
MODIFY `kd_artikel` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `galeri`
--
ALTER TABLE `galeri`
MODIFY `id_galeri` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
MODIFY `kd_kategori` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `komentar_artikel`
--
ALTER TABLE `komentar_artikel`
MODIFY `kd_komartikel` int(7) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `linklist`
--
ALTER TABLE `linklist`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `markers`
--
ALTER TABLE `markers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
