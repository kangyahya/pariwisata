<?php
	$localhost = 'localhost';
	$usern = 'root';
	$pasw = '';
	$con = mysqli_connect($localhost,$usern,$pasw,'db_pariwisata');
	//mysql_select_db('pariwisata');
?>