				<div class="rslides_container">
					<ul class="rslides" id="slider">
						<li><img src="images/5.jpg"/></li>
						<li><img src="images/6.jpg"/></li>
					</ul>
				</div>				
				<?php include "artikel.php"; ?>