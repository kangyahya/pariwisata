<section id="content">
	<div class="zerogrid">
		<div class="row block">
			<div class="main-content col11">
			
				<div class="rslides_container">
					<ul class="rslides" id="slider">
						<li><img src="images/5.jpg"/></li>
						<li><img src="images/6.jpg"/></li>
						<li><img src="images/6.jpg"/></li>
					</ul>
				</div>
				
				<?php include "Artikel.php"; ?>
			</div>
			
			<div class="sidebar col05">
				<?php include "sidebar.php"; ?>
			</div>
	</div>
</section>