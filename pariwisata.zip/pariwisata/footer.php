<p>Copyright © 2017 - Teknik Informatika 2/2</p>
<p><a href="#" target="_blank">STMIK CIC Kota Cirebon</a></p>