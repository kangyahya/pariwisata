				<article>
					
					<div class='content'>
					<div class="lebar" style="width:150px;

						width: auto;
		padding: 15px;
		margin-right: 20px;
		margin-left: 20px;
		float: left;
		background: #fff;
		border: 1px solid #dcdcdc;
		margin-bottom: 20px;
		line-height: 20px;
		-moz-border-radius: 5px;
		-webkit-border-radius: 5px;
		border-radius: 5px;

						"><div class='heading'>
						<h2><a href='#'>About Us</a><hr></h2>
					</div>
						<p><justify>
							<sub>Untuk anda para pembaca web ini, yang ingin artikelnya di posting di web Kami silahkan kirimkan Artikel anda lewat email kami dengan ketentuan : </sub></justify></p>
							<br>1. Berkaitan dengan Pariwisata yang ada di Kota Cirebon
							<br>2. Artikel yang bermutu
							<br>3. Tidak mengandung SARA
							<br>4. Tidak Copy Paste dari website lain.
							<br>
							<br>
						<p>
							<h2>
							Email &nbsp; : <a href='mailto: admin_infopariwisatacrb@gmail.com'>admin_infopariwisatacrb@gmail.com</a>
							</h2>
						</p>	
					</div>
					</div>
				</article>