				<article>
					<div class='heading'>
						<h2><a href='#'>Lokasi Objek Wisata</a></h2>
					</div>
					<div class='content'>
					
					<table>
						<tr>
							<td width="600px"><div id="map" style="width: 550px; height: 520px"></div></td>
						</tr>
					</table>
					<p>
						Peta diatas merupakan peta yang berdasarkan Latitude dan Longitude Kota Cirebon 
					</p>
					</div>
				</article>