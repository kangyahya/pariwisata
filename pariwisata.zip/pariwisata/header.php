<header> 
	<div class="zerogrid">
		<div class="row">
			<div class="col05">
				<div id="logo"><a href=""><img src="./images/log.png"/></a></div>
			</div>
			<div class="col06 offset05">
			   <div id='search-box'>
				  <form action='index.php?page=cari' id='search-form' method='POST' target='_top'>
					<input id='search-text' name='q' placeholder='type here' type='text'/>
					<button id='search-button' type='submit'><span>Search</span></button>
				  </form>
				</div>
			</div>
		</div>
	</div>
</header>