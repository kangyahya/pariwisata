<div id="footer">
<?php
date_default_timezone_set('Asia/Jakarta');
$tahun=date("Y");
?>
&copy; <?php echo $tahun?> <?php echo $ns['isi_pengaturan']?>. <br> Powered by <a href="www.facebook.com/yahya.nobericcirebon"> Muhammad Yahya</a>
</div>
</body>
</html>