  <!-- Basic Page Needs
  ================================================== -->
  <meta charset="utf-8">
  <script src="http://maps.google.com/maps?file=api&amp;v=2&amp;sensor=false&amp;key=AIzaSyDZxi74hCX5kr0R0P8ugFRy6O6dJBfzfgc" type="text/javascript"></script>
 <title>Info Pariwisata kota Cirebon</title>
  
    <!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- CSS
  ================================================== -->
  <link rel="stylesheet" href="css/zerogrid.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
   <link rel="stylesheet" href="css/responsive.css">
  <link rel="stylesheet" href="css/responsiveslides.css" /> 
  <link href='./images/favicon.png' rel='icon' type='image/x-icon'/>
  <link type="text/css" href="js/themes/base/ui.all.css" rel="stylesheet" />
  <!-- Script 
  =================================================-->
  <script src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/highslide.js"></script>
  <script type="text/javascript" src="js/paging.js"></script>
  <script type="text/javascript" src="js/responsiveslides.js"></script> 
  <script language="JavaScript" src="js/gen_validatorv4.js" type="text/javascript" xml:space="preserve"></script>
  <script type="text/javascript" src="js/jquery-1.3.2.js"></script>
    <script type="text/javascript" src="js/ui/ui.core.js"></script>
    <script type="text/javascript" src="js/ui/ui.datepicker.js"></script>

<script type="text/javascript">
  hs.graphicsDir = 'js/graphics/';
  hs.wrapperClassName = 'wide-border';
</script>
       
    


    <script type="text/javascript"> 
      $(document).ready(function(){
        $("#tanggal").datepicker({
    dateFormat  : "yy-mm-dd", 
          changeMonth : true,
          changeYear  : true
      
        });
      });
    
     $(document).ready(function(){
        $("#tanggal1").datepicker({
    dateFormat  : "yy-mm-dd", 
          changeMonth : true,
          changeYear  : true
      
        });
      });
    </script>

  <script>
    $(function () {
      $("#slider").responsiveSlides({
        auto: true,
        pager: true,
        nav: true,
        speed: 500,
        maxwidth: 800,
        namespace: "centered-btns"
      });
    });
  </script>
  <script type="text/javascript" src="js/map.js"></script>