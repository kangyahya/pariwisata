				<article>
					
					<div class='content'>
					<div class="lebar" style="width:150px;

						width: auto;
		padding: 15px;
		margin-right: 20px;
		margin-left: 20px;
		float: left;
		background: #fff;
		border: 1px solid #dcdcdc;
		margin-bottom: 20px;
		line-height: 20px;
		-moz-border-radius: 5px;
		-webkit-border-radius: 5px;
		border-radius: 5px;

						">
						<div class='heading'>
						<h2><a href='#'>Profile</a><hr></h2>
					</div>
						<p><justify>Info Pariwisata adalah website yang menyediakan tentang informasi tempat Objek wisata, Penginapan yang terdekat dari tempat objek wisata, Event dari dari Pengelola Objek wisata yang terkait dan masih banyak lagi</justify></p>
					</div>
					</div>
				</article>